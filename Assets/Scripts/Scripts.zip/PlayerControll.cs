﻿using JetBrains.Annotations;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.SceneManagement;      //씬 변환에 필요한 네임스페이스

public class PlayerControll : MonoBehaviour
{

    public float move_speed;    //이동 속도
    float rayLength = 0.25f;    //Ray와 장애물 간 판정거리

    bool upOk, downOk, rightOk, leftOk = true;

    void Start()
    {
    }

    void Update()
    {
        //씬 변환 함수(스페이스바)
        if (Input.GetKeyDown(KeyCode.Space))
            SceneManager.LoadScene("AnotherScene");

        PlayerMove();
    }

    //캐릭터 조작 함수(WASD)
    public void PlayerMove()
    {
        #region 누른만큼 이동
        //if (Input.GetKeyDown(KeyCode.D))
        //    transform.Translate(Vector3.right * move_speed * Time.deltaTime);
        //else if (Input.GetKeyDown(KeyCode.A))
        //    transform.Translate(Vector3.left * move_speed * Time.deltaTime);
        //else if (Input.GetKeyDown(KeyCode.W))
        //    transform.Translate(Vector3.forward * move_speed * Time.deltaTime);
        //else if (Input.GetKeyDown(KeyCode.S))
        //    transform.Translate(Vector3.back * move_speed * Time.deltaTime); 
        #endregion

        #region 칸 단위로 이동
        if(ObstacleCheck())
        {
                if (Input.GetKeyDown(KeyCode.W))
                {
                    if(upOk == true)
                        transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z + 0.25f);
                }
                if (Input.GetKeyDown(KeyCode.S) && downOk == true)
                {
                    if(downOk == true)
                        transform.position = new Vector3(transform.position.x, transform.position.y, transform.position.z - 0.25f);
                }
                if (Input.GetKeyDown(KeyCode.A) && rightOk == true)
                {
                    if (rightOk == true)
                        transform.position = new Vector3(transform.position.x - 0.25f, transform.position.y, transform.position.z);
                }
                if (Input.GetKeyDown(KeyCode.D) && leftOk == true)
                {
                    if (leftOk == true)
                        transform.position = new Vector3(transform.position.x + 0.25f, transform.position.y, transform.position.z);
                }
        }


        #endregion
    }

    //앞 혹은 옆에 장애물이 있을때 해당 방향으로의 움직임 봉쇄(4방향)
    public bool ObstacleCheck()
    {
        //4방향으로 Ray 생성
        Ray forwardRay = new Ray(transform.position + new Vector3(0, 0, 0), transform.forward);
        Ray backwardRay = new Ray(transform.position + new Vector3(0, 0, 0), -transform.forward);
        Ray rightRay = new Ray(transform.position + new Vector3(0, 0, 0), transform.right);
        Ray leftRay = new Ray(transform.position + new Vector3(0, 0, 0), -transform.right);

        RaycastHit hit;

        Debug.DrawRay(forwardRay.origin, transform.forward, Color.red);
        Debug.DrawRay(forwardRay.origin, -transform.forward, Color.red);
        Debug.DrawRay(forwardRay.origin, transform.right, Color.red);
        Debug.DrawRay(forwardRay.origin, -transform.right, Color.red);

        //4방향 중 근처 장애물 여부 판단 
        if (Physics.Raycast(forwardRay, out hit, rayLength))
        {
            if (hit.collider.tag == "Wall" || hit.collider.tag == "BreakableWall" || hit.collider.tag == "Player")
            {
                upOk = false;
            }
        }
        if (Physics.Raycast(backwardRay, out hit, rayLength))
        {
            if (hit.collider.tag == "Wall" || hit.collider.tag == "BreakableWall" || hit.collider.tag == "Player")
            {
                downOk = false;
            }
        }
        if (Physics.Raycast(rightRay, out hit, rayLength))
        {
            if (hit.collider.tag == "Wall" || hit.collider.tag == "BreakableWall" || hit.collider.tag == "Player")
            {
                rightOk = false;
            }
        }
        if (Physics.Raycast(leftRay, out hit, rayLength))
        {
            if (hit.collider.tag == "Wall" || hit.collider.tag == "BreakableWall" || hit.collider.tag == "Player")
            {
                leftOk = false;
            }
        }
        return true;
    }

    //캐릭터가 향하는 방향을 마우스에 맞춰서
    public void LookAt(Vector3 lookPoint)
    {
        Vector3 heightPoint = new Vector3(lookPoint.x, transform.position.y, lookPoint.z);
        transform.LookAt(heightPoint);  //해당 시점으로 마우스 이동
    }
}
